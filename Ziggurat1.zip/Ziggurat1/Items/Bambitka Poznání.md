---
type:
  - Item
  - weapon
  - pistol
lokace: "[[Agrett]]"
DM: "[[Lapin]]"
vlastník:
  - "[[Rhys]]"
kde: "[[Zbrojnice]]"
magical: true
rarity: Uncommon
attunement: false
banner: "![[Bambitka Poznání.png]]"
summary: 
desc: 
banner_y: 0.544
---
## Popis:
Pokud držíš bambitku v ruce, tak získáváš výhodu na investigation check na hledání pastí a tajných dveří. Také získáš výhodu k jakémukoliv hodu na zjištění původu místa a jeho účelu. (History/religion)

## Statblock

## Lore
Původně patřila kapitánu Barnabášovi z Latrovského ostrovu









![[Bambitka Poznání.png]]