---
type:
  - postava
hráč: "[[Lidi/Lapin]]"
celé jméno: 
příchod: 3425-04-08
gender: Muž
race: Trotle
class:
  - Warlock
práce: Zemědělec
lokace: 
items:
desc: 
banner: 
banner_y: 0.476
---
# [[Navad]]

## Summary

## Poznámky


![[Pasted image 20250501200924.png]]

![[Navad_amulet.gif]]
![[Pasted image 20250501200838.png]]