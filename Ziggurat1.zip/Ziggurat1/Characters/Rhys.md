---
type:
  - postava
hráč: Já
celé jméno: Rhys Tatwin
příchod: 
gender: 
race: 
class: 
práce: 
lokace: 
items: 
desc:
---
# [[Rhys]]

## Summary

## Poznámky
