---
type:
  - Item
lokace: 
DM: 
vlastník: 
kde:
magical: 
rarity: 
attunement: 
banner: 
summary: 
desc: 
---
