---
type:
  - postava
hráč: 
celé jméno: 
příchod: 
gender: 
race: 
class: 
práce: 
lokace: 
items: 
desc:
---
# [[{{title}}]]

## Summary

## Poznámky
