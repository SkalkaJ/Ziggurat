---
type: hráč
postavy: 
jméno: 
gender: 
bydliště:
desc:
---
