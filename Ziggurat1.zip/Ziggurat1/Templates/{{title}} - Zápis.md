---
type: zápis
role: 
lokace: 
DM: 
datum: DD.MM.3425
počet postav:
postavy: 
postava: Rhys
zapisovatel: 
NPCs: 
Monstra: 
banner: 
summary: 
desc:
---
# [[{{title}}]]
## Summary
>summary

## Log


## Zápis
