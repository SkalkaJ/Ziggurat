---
type:
  - hráč
  - DM
postavy:
  - "[[Characters/Ralex]]"
  - "[[Characters/Xal]]"
jméno:
  - Xerius
gender: Muž
bydliště: 
desc:
---
