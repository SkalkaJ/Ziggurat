```dataview
table lokace as "Lokace", datum as "Datum", DM as "DM", zapisovatel as "Zapisovatel" from "Zápisy"
sort datum DESC
```

  