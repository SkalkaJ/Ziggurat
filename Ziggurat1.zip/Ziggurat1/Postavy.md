```dataview
table gender as "Gender", race as "Race", class as "Class", práce as "Práce" from "Characters"
```

